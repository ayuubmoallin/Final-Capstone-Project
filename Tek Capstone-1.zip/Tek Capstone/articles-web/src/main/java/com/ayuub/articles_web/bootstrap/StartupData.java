package com.ayuub.articles_web.bootstrap;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.ayuub.articles_web.model.Article;
import com.ayuub.articles_web.model.Category;
import com.ayuub.articles_web.model.User;
import com.ayuub.articles_web.respository.CategoryRepository;
import com.ayuub.articles_web.respository.UserRepository;

import java.time.LocalDate;
import java.util.*;

@Component
public class StartupData implements CommandLineRunner {

    @Autowired
    PasswordEncoder passwordEncoder;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    @Override
    public void run(String... args) throws Exception {
        createCategories();

        User user = new User();
        user.setFirstName("Ayubb");
        user.setLastName("Moallim");
        user.setUsername("AyubbMoallim@gmail.com");
        user.setPassword(passwordEncoder.encode("Ayubb"));
        user.setActive(true);
        user.setStatus(User.STATUS_ACTIVE);
        user.setRoles(Arrays.asList("USER"));
        user.setArticles(createArticles(user));
        userRepository.save(user);
    }

    private void createCategories(){
        List<Category> categories = new ArrayList<>();

        Category tech = new Category();
        tech.setCategoryName("Technology");
        categories.add(tech);

        Category food = new Category();
        food.setCategoryName("Food");
        categories.add(food);

        Category health = new Category();
        health.setCategoryName("Health");
        categories.add(health);

        categoryRepository.saveAll(categories);
    }


    private Set<Article> createArticles(User user){
        Set<Article> articles = new HashSet<>();

        Article article1 = new Article();

        article1.setTitle("Amazing 5G Technology");
        article1.setCoverImage("https://bestinfopoint.com/images/blogs-images/what-is-5g-technology.jpg");
        article1.setAuthor(user.getFirstName()+" "+user.getLastName());
        article1.setLastUpdatedOn(LocalDate.now());
        article1.setSummary("This new 5g internet technology will have new capabilities that will produce new opportunities for all type of people those uses internet, like businesses, education institutes and societies So what is 5G and why it will change the World? The next fifth-generation of mobile internet connectivity promising much faster data download and upload speeds, wider coverage and more stable connections...");
        article1.setDescription("This new 5g internet technology will have new capabilities that will produce new opportunities for all type of people those uses internet, like businesses, education institutes and societies. So what is 5G and why it will change the World?\n" +
                "\n" +
                "However, One thing you must notice is that when you hear about 5G internet communication, you will think about its fastest speed. Obviously, for observation like kids, the internet speed of 5G technology is very the easiest thing to understand clearly.\n" +
                "But new 5G era is much, much more to understand it...\n" +
                "\n" +
                "The world’s communication and connectivity needs to be change. It means World's mobile data traffic estimated is to multiply by 5 before the ending of year 2024. Particularly mostly in urban areas,where maximum people lives. The current 4G networks simply won’t be able to keep up as must be advance.");
        article1.setCategoryName(categoryRepository.findByCategoryName("Technology").getCategoryName());
        article1.setUser(user);
        articles.add(article1);

        Article article2 = new Article();
        article2.setTitle("12 Things You Must not Eat in Breakfast");
        article2.setCoverImage("https://bestinfopoint.com/images/blogs-images/fresh-breakfast.jpg");
        article2.setAuthor(user.getFirstName()+" "+user.getLastName());
        article2.setLastUpdatedOn(LocalDate.now());
        article2.setSummary("Eating a healthy breakfast can reduce the risk of obesity and high cholesterol, improve performance on memory-related tasks, and minimize impulsive snacking and overeating at other meals. Try this health breakfast hash recipe, which is high in protein and low in calories and saturated fat...");
        article2.setDescription("Following are the most importent things which must not include in breakfast\n" +
                "\n" +
                "1. Fruit Juice\n" +
                "The reason you shouldn’t drink fruit juice in morning with an empty stomach is because of sugar . Even if it’s freshly squeezed or bottle packed fruit juice. You need energy in the morning, not a “sugar crash” caused by falling blood sugar. If you want orange juice, don’t squeeze more than one orange. If possible, drink a glass of water and eat the orange, fiber and all. If you really want to improve your health and daily performance, cut out sugar completely.\n" +
                "\n" +
                "2. Puff Pastries\n" +
                "Food such as shortcrust and puff pastries contain yeast. Yeast has been known to irritate the lining of the stomach. And it can cause yeast. So if you don’t want to fart whole day, try not to eat foods that contain yeast for breakfast.\n" +
                "\n" +
                "3. Doughnut\n" +
                "We all have been loving donuts, but after knowing the harmful fact you won’t eat donuts anymore. Things like donuts are worse. Not only are they made with white flour, they are also packed full of sugar, which is likely to result in a rapid rise in blood sugar. The problem is that this usually causes hunger pains, apart from which too much sugar in the diet is a common cause of fatness, and can also lead to diabetes.");
        article2.setCategoryName(categoryRepository.findByCategoryName("Food").getCategoryName());
        article2.setUser(user);
        articles.add(article2);

        Article article3 = new Article();
        article3.setTitle("What is a Sedentary Lifestyle?");
        article3.setCoverImage("https://bestinfopoint.com/images/blogs-images/Sedentary-lifestyle.jpg");
        article3.setAuthor(user.getFirstName()+" "+user.getLastName());
        article3.setLastUpdatedOn(LocalDate.now());
        article3.setSummary("A person living a sedentary lifestyle is often sitting or lying down while engaged in an activity like reading, socializing, watching television, playing video games, or using a mobile phone/computer for much of the day. A sedentary lifestyle can potentially contribute to ill health and many preventable causes of death...");
        article3.setDescription("A sedentary lifestyle is a type of lifestyle in which a single human being does not get proper amounts of physical activity and exercise. Where physical idleness is supposed the failure to achieve the requirments of the Center for Disease Control (CDC), defining that a single human being (individual) must should do minimum of 140 minutes of average exercise in daily life. That's why many health doctors are also in agreement that walking 8,000 steps in daily life which are almost 5 miles is the most suitable target to set for icreasing health and decreasing the health risks which caused by idleness. As according to new research of World Health Organization (WHO), almost 66 percent to 88 percent of the population worldwide does not engage in enough activity which is recumended for good a health. By Making physical idleness the third growing risk factor for global state of being subject to death.\n" +
                "\n" +
                "Long-established thought recumends that having a healthy diet, food and getting necessary exercise will offset the effects of time spent being sedentary. While If you exercise for 20 minutes a day, you might not be able to reduce the effects brought on by lack of activity throughout the rest of your whole day. Rather, the solution seems to be less sitting and more moving overall. So we recumends the goal for 8 thousand steps in a daily life.");
        article3.setCategoryName(categoryRepository.findByCategoryName("Health").getCategoryName());
        article3.setUser(user);
        articles.add(article3);

        return articles;
    }

}
