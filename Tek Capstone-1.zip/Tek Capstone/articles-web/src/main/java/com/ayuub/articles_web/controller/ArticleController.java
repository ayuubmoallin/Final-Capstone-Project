package com.ayuub.articles_web.controller;

import com.ayuub.articles_web.model.Article;
import com.ayuub.articles_web.service.ArticleService;
import com.ayuub.articles_web.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


@Controller
public class ArticleController {

    @Autowired private ArticleService articleService;
    @Autowired private CategoryService categoryService;

    @RequestMapping(path = "/my-articles", method = RequestMethod.GET)
    public String getMyArticles(Model model){
        model.addAttribute("articles", articleService.getAllArticlesOfLoggedInUser());
        return "my-articles";
    }

    @RequestMapping(path = "/read-article/{id}", method = RequestMethod.GET)
    public String readArticleById(@PathVariable Long id, Model model){
        model.addAttribute("article", articleService.getArticleById(id));
        return "full-article";
    }

    @RequestMapping(path = "/all-articles", method = RequestMethod.GET)
    public String getAllArticles(Model model){
        model.addAttribute("articles", articleService.getAllArticles());
        return "all-articles";
    }

    @RequestMapping(path = "/all-by-category/{categoryName}", method = RequestMethod.GET)
    public String getAllArticles(@PathVariable String categoryName, Model model){
        model.addAttribute("articles", articleService.getAllArticlesByCategoryName(categoryName));
        return "all-articles";
    }

    @RequestMapping(path = "/delete-article/{id}", method = RequestMethod.GET)
    public String deleteArticle(@PathVariable Long id){
        articleService.deleteArticle(id);
        return "redirect:/my-articles";
    }

    @RequestMapping(path = "/add-article", method = RequestMethod.GET)
    public String addArticle(Model model){
        model.addAttribute("categories", categoryService.getAllCategories());
        model.addAttribute("article", new Article());
        return "add-article";
    }

    @RequestMapping(path = "/add-article", method = RequestMethod.POST)
    public String addArticleData(Article article){
        Boolean isSaved = articleService.addArticle(article);
        if (isSaved){
            return "redirect:/my-articles";
        }else {
            return "error";
        }
    }

    @RequestMapping(path = "/update-article/{id}", method = RequestMethod.GET)
    public String updateArticleById(Model model, @PathVariable Long id) {
        model.addAttribute("categories", categoryService.getAllCategories());
        model.addAttribute("article", articleService.getArticleById(id));
        return "update-article";
    }

    @RequestMapping(path = "/update-article", method = RequestMethod.POST)
    public String updateArticleData(Article article){
        Boolean isSaved = articleService.updateArticle(article);
        if (isSaved){
            return "redirect:/my-articles";
        }else {
            return "error";
        }
    }
}
