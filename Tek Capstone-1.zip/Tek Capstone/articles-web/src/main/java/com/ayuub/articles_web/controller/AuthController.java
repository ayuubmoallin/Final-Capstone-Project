package com.ayuub.articles_web.controller;

import com.ayuub.articles_web.model.User;
import com.ayuub.articles_web.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;


@CrossOrigin(maxAge = 3600)
@Controller
public class AuthController {

    @Autowired private UserService userService;

    @RequestMapping(path = "/")
    public String getHome(){
        return "home";
    }

    @RequestMapping(path = "/login")
    public String login(){
        return "login";
    }


    @RequestMapping(path = "/create-account", method = RequestMethod.GET)
    public String getSignupPage(Model model){
        model.addAttribute("status", null);
        model.addAttribute("user", new User());
        return "create-account";
    }

    @RequestMapping(path = "/create-account", method = RequestMethod.POST)
    public String createAccount(User newUserDetail, Model model) {
        LinkedHashMap<String,String> response = userService.createAccount(newUserDetail);
        String templateName = "";
        if (response.get("status").equalsIgnoreCase("200")){
            model.addAttribute("status", response.get("status"));
            model.addAttribute("fullName", response.get("fullName"));
            model.addAttribute("message", response.get("message"));
            templateName = "thankyou";
        }else {
            model.addAttribute("status", response.get("status"));
            model.addAttribute("message", response.get("message"));
            templateName = "create-account";
        }
        return templateName;
    }

    @RequestMapping(path = "/view-profile", method = RequestMethod.GET)
    public String getUserProfile(Model model){
        model.addAttribute("user", userService.getLoggedInUserProfile());
        return "view-profile";
    }

}
