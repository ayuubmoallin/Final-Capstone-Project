package com.ayuub.articles_web.controller;

import com.ayuub.articles_web.model.Category;
import com.ayuub.articles_web.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class CategoryController {

    @Autowired private CategoryService categoryService;

    @RequestMapping(path = "/all-categories", method = RequestMethod.GET)
    public String getAllCategories(Model model){
        model.addAttribute("categories",categoryService.getAllCategories());
        return "all-categories";
    }

    @RequestMapping(path = "/add-category", method = RequestMethod.GET)
    public String createNewCategory(Model model) {
        model.addAttribute("category", new Category());
        return "add-category";
    }

    @RequestMapping(path = "/add-category", method = RequestMethod.POST)
    public String saveNewCategory(Category category) {
        Boolean isSaved = categoryService.addCategory(category);
        if (isSaved){
            return "redirect:/all-categories";
        }else {
            return "error";
        }
    }

    @RequestMapping(path = "/update-category/{id}", method = RequestMethod.GET)
    public String updateCategoryById(Model model, @PathVariable Long id) {
        model.addAttribute("category", categoryService.getCategoryById(id));
        return "update-category";
    }

    @RequestMapping(path = "/update-category", method = RequestMethod.POST)
    public String updateCategory(Category category) {
        Boolean isSaved = categoryService.updateCategory(category);
        if (isSaved){
            return "redirect:/all-categories";
        }else {
            return "error";
        }
    }


    @RequestMapping(path = "/delete-category/{id}", method = RequestMethod.GET)
    public String deleteCategoryById(@PathVariable Long id){
        categoryService.deleteCategory(id);
        return "redirect:/all-categories";
    }

}
