package com.ayuub.articles_web.controller;

import com.ayuub.articles_web.service.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class CommentController {

    @Autowired private CommentService commentService;

    @RequestMapping(path = "/add-comment/{articleId}/{comment}", method = RequestMethod.GET)
    public String addComment(@PathVariable Long articleId, @PathVariable String comment){
        Boolean isSaved = commentService.addComment(articleId, comment);
        if (isSaved){
            return "redirect:/read-article/"+articleId;
        }else {
            return "error";
        }
    }
}
