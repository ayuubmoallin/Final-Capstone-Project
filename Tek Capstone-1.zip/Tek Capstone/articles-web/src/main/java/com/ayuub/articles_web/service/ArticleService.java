package com.ayuub.articles_web.service;

import com.ayuub.articles_web.model.Article;
import com.ayuub.articles_web.model.Category;
import com.ayuub.articles_web.model.User;
import com.ayuub.articles_web.respository.ArticleRepository;
import com.ayuub.articles_web.respository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

@Service
public class ArticleService {

    @Autowired private ArticleRepository articleRepository;
    @Autowired private CategoryService categoryService;
    @Autowired private UserRepository userRepository;
    @Autowired private UserService userService;

    public Boolean addArticle(Article article){
        User user = userService.getLoggedInUserProfile();

        article.setAuthor(user.getFirstName()+" "+user.getLastName());
        article.setLastUpdatedOn(LocalDate.now());

        Category category = categoryService.getCategoryByName(article.getCategoryName());
        if(category != null){
            article.setCategoryName(category.getCategoryName());
            article.setUser(user);
            Set<Article> articles = user.getArticles();
            articles.add(article);
            user.setArticles(articles);
            userRepository.save(user);
            return true;
        }else {
            return false;
        }
    }

    public Article getArticleById(Long id){
        return articleRepository.findById(id).get();
    }

    public Boolean updateArticle(Article article){

        User user = userService.getLoggedInUserProfile();

        Category category = categoryService.getCategoryByName(article.getCategoryName());
        if(category != null){

            Boolean isSaved = false;

            Set<Article> articles = user.getArticles();

            Iterator<Article> articleIterator = articles.iterator();

            while (articleIterator.hasNext()){
                Article articleFromDB = articleIterator.next();
                if (articleFromDB.getId() == article.getId()){
                    articles.remove(articleFromDB);
                    articleFromDB.setCategoryName(category.getCategoryName());
                    articleFromDB.setTitle(article.getTitle());
                    articleFromDB.setCoverImage(article.getCoverImage());
                    articleFromDB.setSummary(article.getSummary());
                    articleFromDB.setDescription(article.getDescription());
                    articleFromDB.setLastUpdatedOn(LocalDate.now());
                    articles.add(articleFromDB);
                    user.setArticles(articles);
                    userRepository.save(user);
                    isSaved = true;
                    break;
                }
            }
            return isSaved;
        }else {
            return false;
        }
    }

    public boolean deleteArticle(Long id){
        articleRepository.delete(articleRepository.findById(id).get());
        return true;
    }

    public Set<Article> getAllArticlesOfLoggedInUser(){
        User loggedInUser = userService.getLoggedInUserProfile();
        return loggedInUser.getArticles();
    }

    public List<Article> getAllArticles(){
        return articleRepository.findAll();
    }

    public List<Article> getAllArticlesByCategoryName(String categoryName){
        return articleRepository.findAllByCategoryName(categoryName);
    }

}
