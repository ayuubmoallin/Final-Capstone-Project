package com.ayuub.articles_web.service;

import com.ayuub.articles_web.model.Category;
import com.ayuub.articles_web.respository.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategoryService {

    @Autowired
    private CategoryRepository categoryRepository;

    public Boolean addCategory(Category category){
        categoryRepository.save(category);
        return true;
    }

    public Category getCategoryByName(String categoryName){
        return categoryRepository.findByCategoryName(categoryName);
    }

    public Category getCategoryById(Long id){
        return categoryRepository.findById(id).get();
    }

    public Boolean updateCategory(Category category){
        Category categoryFromDB = categoryRepository.findById(category.getId()).get();
        categoryFromDB.setCategoryName(category.getCategoryName());
        categoryRepository.save(category);
        return true;
    }

    public boolean deleteCategory(Long id){
        categoryRepository.delete(categoryRepository.findById(id).get());
        return true;
    }

    public List<Category> getAllCategories(){
        return categoryRepository.findAll();
    }

}
