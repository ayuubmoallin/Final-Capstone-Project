package com.ayuub.articles_web.service;

import com.ayuub.articles_web.model.Article;
import com.ayuub.articles_web.model.Comment;
import com.ayuub.articles_web.model.User;
import com.ayuub.articles_web.respository.ArticleRepository;
import com.ayuub.articles_web.respository.CommentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CommentService {

    @Autowired private UserService userService;
    @Autowired private ArticleService articleService;
    @Autowired private CommentRepository commentRepository;
    @Autowired private ArticleRepository articleRepository;

    public Boolean addComment(Long articleId, String commentText){
        User user = userService.getLoggedInUserProfile();
        Comment comment = new Comment();
        comment.setComment(commentText);
        comment.setAuthorName(user.getFirstName()+" "+user.getLastName());
        Article article = articleService.getArticleById(articleId);
        comment.setArticle(article);
        commentRepository.save(comment);
        return true;
    }

}
