package com.ayuub.articles_Web.controller;



import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ArticleControllerTest {

    @Test
    void getMyArticles() {
    }

    @Test
    void readArticleById() {
    }

    @Test
    void getAllArticles() {
    }

    @Test
    void testGetAllArticles() {
    }

    @Test
    void deleteArticle() {
    }

    @Test
    void addArticle() {
    }

    @Test
    void addArticleData() {
    }

    @Test
    void updateArticleById() {
    }

    @Test
    void updateArticleData() {
    }


}