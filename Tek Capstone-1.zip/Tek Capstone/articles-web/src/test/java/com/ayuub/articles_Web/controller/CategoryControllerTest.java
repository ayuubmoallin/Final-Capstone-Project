package com.ayuub.articles_Web.controller;



import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CategoryControllerTest {

    @Test
    void getAllCategories() {
    }

    @Test
    void createNewCategory() {
    }

    @Test
    void saveNewCategory() {
    }

    @Test
    void updateCategoryById() {
    }

    @Test
    void updateCategory() {
    }

    @Test
    void deleteCategoryById() {
    }
}