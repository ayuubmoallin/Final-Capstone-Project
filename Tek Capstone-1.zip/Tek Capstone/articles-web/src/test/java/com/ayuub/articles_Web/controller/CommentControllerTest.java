package com.ayuub.articles_Web.controller;



import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CommentControllerTest {

    @Test
    void addComment() {
    }

}